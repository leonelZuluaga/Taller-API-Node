import express from 'express';
import os from 'os';
import {read, write} from './leito/elMasBonito/files.js';

const app = express();
app.use(express.json());


app.get('/juegos', (req, res) => {
  console.log('os.cpus',os.cpus());
  const juegos = read();
  let done = req.query.done;
  if (done === 'true') {
    done = true;
  }else if (done === 'false'){
    done = false
  }

  console.log('req.query',req.query);
  console.log('juegos', juegos);
  if (req.query.done){
    res.json(juegos.filter(juego => juego.done === done));
    return;
  }
  console.log('juegos',juegos);
  res.setHeader('Content-Type', 'application/json');
  res.end((JSON.stringify(juegos)));
})


app.post('/juegos', 
  (req,res) =>{
    const juegos = read();
    const juego = {
        ...req.body, //spread operator
        id: juegos.length +1
    }
    juegos.push(juego);
    write(juegos);
    //Codigo HTTP 201 Created
    res.status(201).json(juegos);
})

app.get('/juegos/:id', (req, res) =>{
  const juegos = read();
  const juego = juegos.find(juego => juego.id === parseInt(req.params.id));
  if (juego) {
    res.json(juego);
  } else {
      res.status(404).end();
  }
})

app.put('/juegos/:id', (req,res)=>{
  const juegos = read();
  let juego = juegos.find(juego => juego.id === parseInt(req.params.id));
  if (juego){
    juego = {
      ...juego,
      ...req.body
    }
    //actualizar juegos en el array
    juegos[
      juegos.findIndex(juego => juego.id === parseInt(req.params.id))
    ] = juego;
    write(juegos);
    res.json(juego)
  } else{
    res.status(404).end();
  }
})

app.delete('/juegos/:id', (req,res) => {
  const juegos = read();
  const juego = juegos.find(juego => juego.id === parseInt(req.params.id));
  if (juego){
    //Eliminar juego
    juegos.splice(
      juegos.findIndex(juego => juego.id === parseInt(req.params.id)),
      1
    );
    write(juegos);
    res.json(juego);
  } else{
    res.status(404).end();
  }
})

app.listen(3000, () => {
  console.log(`Server is running on port 3000`)
})